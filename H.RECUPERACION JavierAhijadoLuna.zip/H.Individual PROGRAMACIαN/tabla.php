<?php
$consulta = "SELECT * FROM bd_formulario";
$conexion = new mysqli('localhost', 'root','','bd_formulario' );

$insertar = $conexion->prepare($consulta);
$resultado = $conexion->query($consulta);

echo("<table border='1'>");
    echo("<tr>");
        echo("<th>Email</th>");
        echo("<th>Título</th>");
        echo("<th>Contenido</th>");
        echo("<th>Fecha</th>");
        echo("<th>Imagen</th>");
    echo("</tr>");
    while($row=$resultado->fetch_assoc()){
        echo("<tr>");
            echo("<td>".$row["EMAIL"]."</td>");
            echo("<td>".$row["TITULO"]."</td>");
            echo("<td>".$row["CONTENIDO"]."</td>");
            echo("<td>".$row["FECHA"]."</td>");
            echo("<td>".$row["IMAGEN"]."</td>");
        echo("</tr>");
    }
echo("</table>");