<?php
$correo = $_POST['email'];

