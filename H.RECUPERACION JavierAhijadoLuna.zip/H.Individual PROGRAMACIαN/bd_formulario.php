<?php
INSERT INTO `bd_formulario` (`ID`, `EMAIL`, `TITULO`, `CONTENIDO`, `FECHA`, `IMAGEN`) VALUES (NULL, 'javier@gmail.com', 'DIFERENCIAS ENTRE LENGUAJE...', 'Encontramos la diferencia', '2023-02-23', 'PROGRAMACIÓN');
?>