<?php
session_start();
// Recoger los datos del formulario
$email = $_POST['email'];
$titulo = $_POST['titulo'];
$contenido = $_POST['contenido'];
$fecha = $_POST['fecha'];
$imagen = $_POST['imagen'];

$conexion = new mysqli('localhost', 'root','','bd_formulario' );
$consulta = "INSERT INTO `bd_formulario` (`ID`, `EMAIL`, `TITULO`, `CONTENIDO`, `FECHA`, `IMAGEN`) VALUES (NULL,?,?,?,?,?);"; 
$insertar = $conexion->prepare($consulta);
$resultado = $insertar->execute([$email, $titulo, $contenido, $fecha, $imagen]);